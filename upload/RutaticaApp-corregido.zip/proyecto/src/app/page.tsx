'use client'

import { useState, useEffect } from 'react'
import { MapPin, Bus, Navigation, Clock, DollarSign, ArrowRight, Loader2, Map, Home, Star, Bell, Menu, Search, Heart, User, Wallet, X, ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet'
import BusMap from '@/components/map'
import LocationAutocomplete from '@/components/location-autocomplete'

interface PlanatedRoute {
  id: string
  company: string
  routeNumber: string
  origin: string
  destination: string
  price: number
  currency: string
  distanceKm?: number | null
  durationMin?: number | null
  boardingStop: {
    name: string
    city: string | null
    coordinates?: {
      latitude: number
      longitude: number
    }
  }
  destinationStop: {
    name: string
    city: string | null
    coordinates?: {
      latitude: number
      longitude: number
    } | null
  } | null
  nearbyStops: Array<{
    name: string
    city: string | null
    distance: number
  }>
}

interface Location {
  latitude: number
  longitude: number
}

interface NearestStop {
  name: string
  city: string | null
  distance: number
  coordinates: {
    latitude: number
    longitude: number
  }
}

interface SelectedLocation {
  name: string
  lat: number
  lon: number
  displayName?: string
}

interface RoutePath {
  walking?: [number, number][]
  bus?: [number, number][]
  direct?: [number, number][]
}

interface BusStop {
  id: string
  name: string
  lat: number
  lon: number
}

export default function BusPlannerApp() {
  const [currentLocation, setCurrentLocation] = useState<Location | null>(null)
  const [currentAddress, setCurrentAddress] = useState<string>('')
  const [nearestStop, setNearestStop] = useState<NearestStop | null>(null)
  const [destination, setDestination] = useState('')
  const [selectedDestination, setSelectedDestination] = useState<SelectedLocation | null>(null)
  const [plannedRoutes, setPlannedRoutes] = useState<PlanatedRoute[]>([])
  const [selectedRoute, setSelectedRoute] = useState<PlanatedRoute | null>(null)
  const [routePath, setRoutePath] = useState<RoutePath | null>(null)
  const [busStops, setBusStops] = useState<BusStop[] | null>(null)
  const [hasPlanned, setHasPlanned] = useState(false)
  const [loadingLocation, setLoadingLocation] = useState(false)
  const [loadingAddress, setLoadingAddress] = useState(false)
  const [planning, setPlanning] = useState(false)
  const [loadingRoute, setLoadingRoute] = useState(false)
  const [loadingDirectRoute, setLoadingDirectRoute] = useState(false)
  const [loadingBusStops, setLoadingBusStops] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showFullAddress, setShowFullAddress] = useState(true)
  const [addressData, setAddressData] = useState<any>(null)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  // Estados para seguimiento de viaje
  const [isTracking, setIsTracking] = useState(false)
  const [trackingId, setTrackingId] = useState<number | null>(null)
  const [tripStartTime, setTripStartTime] = useState<Date | null>(null)
  const [distanceRemaining, setDistanceRemaining] = useState<number>(0)
  const [distanceTraveled, setDistanceTraveled] = useState<number>(0)
  const [elapsedTime, setElapsedTime] = useState<number>(0)
  const [showArrivalNotification, setShowArrivalNotification] = useState(false)

  // Estados para panel de seguimiento
  const [trackingPanelVisible, setTrackingPanelVisible] = useState(true)

  // Estados para control del mapa
  const [mapCenter, setMapCenter] = useState<[number, number] | null>(null)
  const [mapZoom, setMapZoom] = useState(14)
  const [mapBounds, setMapBounds] = useState<[[number, number], [number, number]] | null>(null)
  const [isUserInteracting, setIsUserInteracting] = useState(false)
  const [lastUserActivity, setLastUserActivity] = useState(0)
  const [manualCenter, setManualCenter] = useState<[number, number] | null>(null)

  // Estado para alerta de inicio de viaje con conteo
  const [showStartTripAlert, setShowStartTripAlert] = useState(false)
  const [countdownSeconds, setCountdownSeconds] = useState(30)
  const [showStopTripButton, setShowStopTripButton] = useState(false)

  // Estado para visibilidad de detalles del viaje
  const [tripDetailsVisible, setTripDetailsVisible] = useState(false)

  // Estado para alternar entre distancia y tiempo
  const [showDistance, setShowDistance] = useState(true)

  useEffect(() => {
    getCurrentLocation()
  }, [])

  // Auto-centrar el mapa después de 15 segundos de inactividad
  useEffect(() => {
    const interval = setInterval(() => {
      if (isTracking && !isUserInteracting && lastUserActivity > 0 && Date.now() - lastUserActivity > 15000) {
        if (currentLocation) {
          setMapCenter([currentLocation.latitude, currentLocation.longitude])
          setMapZoom(14)
          setLastUserActivity(0)
        }
      }
    }, 1000)
    return () => clearInterval(interval)
  }, [isTracking, isUserInteracting, lastUserActivity, currentLocation])

  const getAddressFromCoordinates = async (lat: number, lon: number): Promise<string> => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&accept-language=es`
      )
      const data = await response.json()
      setAddressData(data)
      return formatAddress(data, showFullAddress)
    } catch (error) {
      console.error('Error al obtener dirección:', error)
      return ''
    }
  }

  const formatAddress = (data: any, useFullAddress: boolean): string => {
    if (!data || !data.address) return ''
    const addr = data.address
    const parts: string[] = []

    if (useFullAddress) {
      if (addr.road) {
        if (addr.house_number) {
          parts.push(`${addr.road} ${addr.house_number}`)
        } else {
          parts.push(addr.road)
        }
      }
      if (addr.neighbourhood) parts.push(addr.neighbourhood)
      else if (addr.suburb) parts.push(addr.suburb)
      if (addr.village) {
        parts.push(addr.village)
      } else if (addr.town) {
        parts.push(addr.town)
      } else if (addr.city) {
        parts.push(addr.city)
      }
      if (addr.city && !parts.includes(addr.city)) {
        parts.push(addr.city)
      } else if (addr.town && !parts.includes(addr.town)) {
        parts.push(addr.town)
      } else if (addr.city_district) {
        parts.push(addr.city_district)
      }
      if (addr.county) {
        parts.push(addr.county)
      }
      if (addr.state) {
        parts.push(addr.state)
      }
      if (addr.postcode) {
        parts.push(addr.postcode)
      }
    } else {
      if (addr.road) {
        if (addr.house_number) {
          parts.push(`${addr.road} ${addr.house_number}`)
        } else {
          parts.push(addr.road)
        }
      }
      if (addr.neighbourhood) parts.push(addr.neighbourhood)
      else if (addr.suburb) parts.push(addr.suburb)
      if (addr.village) {
        parts.push(addr.village)
      } else if (addr.town) {
        parts.push(addr.town)
      } else if (addr.city) {
        parts.push(addr.city)
      }
    }

    return parts.join(', ')
  }

  useEffect(() => {
    if (addressData) {
      setCurrentAddress(formatAddress(addressData, showFullAddress))
    }
  }, [showFullAddress])

  // Actualizar tiempo transcurrido durante el viaje
  useEffect(() => {
    if (!isTracking || !tripStartTime) {
      return
    }

    const interval = setInterval(() => {
      const elapsed = (Date.now() - tripStartTime.getTime()) / 1000 / 60 // en minutos
      setElapsedTime(elapsed)
    }, 1000)

    return () => {
      clearInterval(interval)
    }
  }, [isTracking, tripStartTime])

  const getCurrentLocation = async () => {
    setLoadingLocation(true)
    setError(null)
    try {
      if (!navigator.geolocation) {
        setError('La geolocalización no está soportada en tu navegador')
        setLoadingLocation(false)
        setLoadingAddress(false)
        return
      }

      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          resolve,
          reject,
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0,
          }
        )
      })

      const { latitude, longitude } = position.coords
      setCurrentLocation({ latitude, longitude })
      setMapCenter([latitude, longitude])
      setMapZoom(16)

      // Cargar dirección en segundo plano sin bloquear
      setLoadingAddress(true)
      getAddressFromCoordinates(latitude, longitude)
        .then((address) => {
          setCurrentAddress(address)
        })
        .catch((error) => {
          console.error('Error al obtener dirección:', error)
        })
        .finally(() => {
          setLoadingAddress(false)
        })
    } catch (error) {
      console.error('Error al obtener ubicación:', error)
      setError('No se pudo obtener tu ubicación. Por favor activa el GPS y permite el acceso.')
    } finally {
      setLoadingLocation(false)
    }
  }

  // Función para enfocar en la ubicación actual
  const handleFocusLocation = () => {
    if (currentLocation) {
      setMapCenter([currentLocation.latitude, currentLocation.longitude])
      setMapZoom(16)
    }
  }

  const findNearestStop = async (lat: number, lon: number) => {
    try {
      const response = await fetch(
        `/api/routes/nearby?lat=${lat}&lon=${lon}`
      )
      const data = await response.json()
      if (data.success) {
        if (data.routes && data.routes.length > 0) {
        }
      }
    } catch (error) {
      console.error('Error al buscar parada cercana:', error)
    }
  }

  // Función para obtener ruta de OSRM (Open Source Routing Machine)
  const getOSRMRoute = async (start: [number, number], end: [number, number], profile: 'walking' | 'driving' = 'driving') => {
    try {
      // Validar coordenadas de entrada
      if (!isFinite(start[0]) || !isFinite(start[1]) || !isFinite(end[0]) || !isFinite(end[1])) {
        console.error('Coordenadas de inicio/fin inválidas:', { start, end })
        return null
      }

      const url = `https://router.project-osrm.org/route/v1/${profile}/${start[1]},${start[0]};${end[1]},${end[0]}?overview=full&geometries=geojson`
      const response = await fetch(url)
      const data = await response.json()

      if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
        const route = data.routes[0]
        // Extraer las coordenadas de la ruta y filtrar valores inválidos
        const allCoordinates = route.geometry.coordinates.map((coord: number[]) => [coord[1], coord[0]]) as [number, number][]

        // Filtrar solo coordenadas válidas (no NaN ni infinito)
        const validCoordinates = allCoordinates.filter((coord: [number, number]) =>
          isFinite(coord[0]) && isFinite(coord[1])
        )

        if (validCoordinates.length === 0) {
          console.warn('No hay coordenadas válidas en la ruta de OSRM')
          return null
        }

        if (validCoordinates.length < allCoordinates.length) {
          console.warn(`Se filtraron ${allCoordinates.length - validCoordinates.length} coordenadas inválidas de OSRM`)
        }

        return validCoordinates
      }
      return null
    } catch (error) {
      console.error('Error al obtener ruta de OSRM:', error)
      return null
    }
  }

  // Función para obtener paradas de autobús de OpenStreetMap usando Overpass API
  const getBusStopsFromOSM = async (bounds: { south: number; west: number; north: number; east: number }) => {
    try {
      setLoadingBusStops(true)
      const query = `
        [out:json][timeout:25];
        (
          node["public_transport"="platform"]["bus"="yes"](${bounds.south},${bounds.west},${bounds.north},${bounds.east});
          node["highway"="bus_stop"](${bounds.south},${bounds.west},${bounds.north},${bounds.east});
        );
        out body;
        >;
        out skel qt;
      `

      const response = await fetch('https://overpass-api.de/api/interpreter', {
        method: 'POST',
        body: query,
      })

      const data = await response.json()

      if (data.elements && data.elements.length > 0) {
        const stops: BusStop[] = data.elements
          .filter((el: any) => el.type === 'node' && el.lat && el.lon)
          .map((el: any) => ({
            id: el.id.toString(),
            name: el.tags?.name || el.tags?.ref || `Parada ${el.id}`,
            lat: el.lat,
            lon: el.lon,
          }))

        // Limitar a las 50 paradas más cercanas para no saturar el mapa
        return stops.slice(0, 50)
      }

      return []
    } catch (error) {
      console.error('Error al obtener paradas de autobús:', error)
      return []
    } finally {
      setLoadingBusStops(false)
    }
  }

  // Calcular los límites del área alrededor de la ruta
  const getRouteBounds = (routePath: RoutePath | null) => {
    if (!routePath) return null

    const allPoints: [number, number][] = []

    if (routePath.walking) {
      allPoints.push(...routePath.walking)
    }
    if (routePath.bus) {
      allPoints.push(...routePath.bus)
    }
    if (routePath.direct) {
      allPoints.push(...routePath.direct)
    }

    if (allPoints.length === 0) return null

    // Validar que todos los puntos tengan coordenadas válidas
    const validPoints = allPoints.filter(p =>
      isFinite(p[0]) && isFinite(p[1])
    )

    if (validPoints.length === 0) {
      console.warn('No hay puntos válidos para calcular bounds', allPoints)
      return null
    }

    const lats = validPoints.map(p => p[0])
    const lons = validPoints.map(p => p[1])

    const margin = 0.01 // Aproximadamente 1 km de margen

    return {
      south: Math.min(...lats) - margin,
      west: Math.min(...lons) - margin,
      north: Math.max(...lats) + margin,
      east: Math.max(...lons) + margin,
    }
  }

  // Calcular centro y zoom para mostrar toda la ruta usando bounds
  const fitRouteToBounds = (routePath: RoutePath | null) => {
    if (!routePath) return

    const bounds = getRouteBounds(routePath)
    if (!bounds) return

    // Set bounds para que el mapa use fitBounds
    setMapBounds([[bounds.south, bounds.west], [bounds.north, bounds.east]])

    // Limpiar mapBounds después de 1 segundo para permitir interacción del usuario
    setTimeout(() => {
      setMapBounds(null)
    }, 1000)
  }

  const handleDestinationSelect = (location: any) => {
    try {
      // Validar que la ubicación tenga los datos necesarios
      if (!location || !location.lat || !location.lon) {
        console.error('Ubicación inválida:', location)
        setError('La ubicación seleccionada no tiene coordenadas válidas')
        return
      }

      const lat = parseFloat(location.lat)
      const lon = parseFloat(location.lon)

      if (isNaN(lat) || isNaN(lon)) {
        console.error('Coordenadas inválidas:', { lat, lon, location })
        setError('Las coordenadas seleccionadas no son válidas')
        return
      }

      setSelectedDestination({
        name: location.name || 'Destino desconocido',
        lat: lat,
        lon: lon,
        displayName: location.displayName || location.name || 'Destino desconocido',
      })
      // Limpiar el textbox de búsqueda después de seleccionar
      setDestination('')
      setError(null)
      
      // Esconder el menú principal
      setIsMenuOpen(false)

      // Obtener ruta directa al destino seleccionado
      if (currentLocation && isFinite(currentLocation.latitude) && isFinite(currentLocation.longitude)) {
        getDirectRouteToDestination([currentLocation.latitude, currentLocation.longitude], [lat, lon])
      } else {
        console.warn('Ubicación actual inválida, no se puede obtener ruta directa:', currentLocation)
      }

      // Mostrar alerta con conteo de 30 segundos
      setShowStartTripAlert(true)
      setCountdownSeconds(30)
    } catch (error) {
      console.error('Error al seleccionar destino:', error)
      setError('Error al procesar la ubicación seleccionada')
    }
  }

  // Función para obtener ruta directa al destino seleccionado
  const getDirectRouteToDestination = async (start: [number, number], end: [number, number]) => {
    try {
      // Validar coordenadas de entrada
      if (!isFinite(start[0]) || !isFinite(start[1]) || !isFinite(end[0]) || !isFinite(end[1])) {
        console.error('Coordenadas de inicio/fin inválidas en getDirectRouteToDestination:', { start, end })
        return
      }

      setLoadingDirectRoute(true)
      const route = await getOSRMRoute(start, end, 'driving')
      if (route && route.length > 0) {
        setRoutePath({ direct: route })
        // Zoom out para mostrar toda la ruta
        fitRouteToBounds({ direct: route })
      } else {
        console.warn('No se pudo obtener ruta directa desde getOSRMRoute')
      }
    } catch (error) {
      console.error('Error al obtener ruta directa:', error)
    } finally {
      setLoadingDirectRoute(false)
    }
  }

  const handlePlanRoute = async () => {
    if (!destination.trim() || !currentLocation) {
      setError('Por favor ingresa un destino y espera a obtener tu ubicación')
      return
    }

    setPlanning(true)
    setLoadingRoute(true)
    setError(null)
    setSelectedRoute(null)
    setRoutePath(null)
    setBusStops(null)

    try {
      const response = await fetch(
        `/api/routes/plan?lat=${currentLocation.latitude}&lon=${currentLocation.longitude}&destination=${encodeURIComponent(destination)}`
      )
      const data = await response.json()

      if (data.success) {
        setPlannedRoutes(data.routes)
        setNearestStop(data.nearestStop)
        setHasPlanned(true)

        if (data.routes.length > 0) {
          setSelectedRoute(data.routes[0])

          // Obtener rutas reales de las calles usando OSRM
          const route = data.routes[0]
          const newRoutePath: RoutePath = {}

          // Ruta caminando desde ubicación actual hasta parada de embarque
          if (route.boardingStop?.coordinates && currentLocation) {
            const boardLat = route.boardingStop.coordinates.latitude
            const boardLon = route.boardingStop.coordinates.longitude
            // Validar coordenadas antes de obtener ruta
            if (isFinite(boardLat) && isFinite(boardLon)) {
              const walkingRoute = await getOSRMRoute(
                [currentLocation.latitude, currentLocation.longitude],
                [boardLat, boardLon],
                'walking'
              )
              if (walkingRoute) {
                newRoutePath.walking = walkingRoute
              }
            } else {
              console.warn('Coordenadas de boardingStop inválidas:', route.boardingStop.coordinates)
            }
          }

          // Ruta en autobús desde parada de embarque hasta destino
          if (route.boardingStop?.coordinates && route.destinationStop?.coordinates) {
            const boardLat = route.boardingStop.coordinates.latitude
            const boardLon = route.boardingStop.coordinates.longitude
            const destLat = route.destinationStop.coordinates.latitude
            const destLon = route.destinationStop.coordinates.longitude
            // Validar coordenadas antes de obtener ruta
            if (isFinite(boardLat) && isFinite(boardLon) && isFinite(destLat) && isFinite(destLon)) {
              const busRoute = await getOSRMRoute(
                [boardLat, boardLon],
                [destLat, destLon],
                'driving'
              )
              if (busRoute) {
                newRoutePath.bus = busRoute
              }
            } else {
              console.warn('Coordenadas de boardingStop o destinationStop inválidas:', {
                boarding: route.boardingStop?.coordinates,
                destination: route.destinationStop?.coordinates
              })
            }
          }

          setRoutePath(newRoutePath)

          // Ajustar mapa para mostrar toda la ruta
          fitRouteToBounds(newRoutePath)

          // Obtener paradas de autobús de OpenStreetMap alrededor de la ruta
          const bounds = getRouteBounds(newRoutePath)
          if (bounds) {
            const stops = await getBusStopsFromOSM(bounds)
            setBusStops(stops)
          }
        }

        if (data.routes.length === 0) {
          setError('No se encontraron rutas hacia ese destino. Intenta con otro destino.')
        }
      } else {
        setError(data.error || 'Error al planificar la ruta')
      }
    } catch (error) {
      console.error('Error al planificar ruta:', error)
      setError('Error de conexión. Por favor intenta de nuevo.')
    } finally {
      setPlanning(false)
      setLoadingRoute(false)
    }
  }

  const handleResetSearch = () => {
    // Detener seguimiento si está activo
    if (trackingId) {
      navigator.geolocation.clearWatch(trackingId)
      setTrackingId(null)
    }

    setIsTracking(false)
    setTripStartTime(null)
    setElapsedTime(0)
    setDistanceRemaining(0)
    setShowArrivalNotification(false)
    setTrackingPanelVisible(true)
    setShowStartTripAlert(false)

    setDestination('')
    setSelectedDestination(null)
    setPlannedRoutes([])
    setSelectedRoute(null)
    setRoutePath(null)
    setBusStops(null)
    setHasPlanned(false)
    setError(null)

    // Resetear mapa
    if (currentLocation) {
      setMapCenter([currentLocation.latitude, currentLocation.longitude])
      setMapZoom(14)
    }
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('es-CR', {
      style: 'currency',
      currency: 'CRC',
      minimumFractionDigits: 0,
    }).format(price)
  }

  const formatDistance = (km: number | null | undefined) => {
    if (!km) return null
    return `${km} km`
  }

  const formatDuration = (min: number | null | undefined) => {
    if (!min) return null
    const hours = Math.floor(min / 60)
    const mins = min % 60
    if (hours === 0) return `${mins} min`
    if (mins === 0) return `${hours} h`
    return `${hours} h ${mins} min`
  }

  // Calcular distancia entre dos coordenadas usando Haversine
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    // Validar coordenadas de entrada
    if (!isFinite(lat1) || !isFinite(lon1) || !isFinite(lat2) || !isFinite(lon2)) {
      console.error('Coordenadas inválidas en calculateDistance:', { lat1, lon1, lat2, lon2 })
      return 0
    }

    const R = 6371 // Radio de la Tierra en km
    const dLat = (lat2 - lat1) * Math.PI / 180
    const dLon = (lon2 - lon1) * Math.PI / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  const handleStartTrip = () => {
    if (!currentLocation) {
      return
    }

    setIsTracking(true)
    setTripStartTime(new Date())
    setElapsedTime(0)
    setDistanceTraveled(0)
    setTrackingPanelVisible(false) // Esconder panel al empezar

    // Calcular distancia inicial al destino
    if (selectedRoute?.destinationStop?.coordinates) {
      const destLat = selectedRoute.destinationStop.coordinates.latitude
      const destLon = selectedRoute.destinationStop.coordinates.longitude
      if (isFinite(destLat) && isFinite(destLon)) {
        const initialDistance = calculateDistance(
          currentLocation.latitude,
          currentLocation.longitude,
          destLat,
          destLon
        )
        setDistanceRemaining(initialDistance)
      } else {
        console.warn('Coordenadas de destinationStop inválidas:', selectedRoute.destinationStop.coordinates)
        setDistanceRemaining(0)
      }
    } else if (selectedDestination) {
      const destLat = selectedDestination.lat
      const destLon = selectedDestination.lon
      if (isFinite(destLat) && isFinite(destLon)) {
        const initialDistance = calculateDistance(
          currentLocation.latitude,
          currentLocation.longitude,
          destLat,
          destLon
        )
        setDistanceRemaining(initialDistance)
      } else {
        console.warn('Coordenadas de selectedDestination inválidas:', selectedDestination)
        setDistanceRemaining(0)
      }
    }

    // Centrar mapa en ubicación actual
    setMapCenter([currentLocation.latitude, currentLocation.longitude])
    setMapZoom(14)

    // Guardar última ubicación para calcular distancia recorrida
    let lastPosition: [number, number] = [currentLocation.latitude, currentLocation.longitude]

    // Iniciar seguimiento de posición con watchPosition
    const id = navigator.geolocation.watchPosition(
      (position) => {
        const { latitude, longitude } = position.coords

        // Validar coordenadas del GPS antes de procesar
        if (!isFinite(latitude) || !isFinite(longitude)) {
          console.warn('Coordenadas de GPS inválidas en watchPosition:', { latitude, longitude })
          return
        }

        const currentPosition: [number, number] = [latitude, longitude]
        setCurrentLocation({ latitude, longitude })

        // Calcular distancia recorrida incrementalmente
        const segmentDistance = calculateDistance(
          lastPosition[0],
          lastPosition[1],
          currentPosition[0],
          currentPosition[1]
        )
        // Solo agregar si el movimiento es significativo (más de 5 metros para evitar errores de GPS)
        if (segmentDistance > 0.005) {
          setDistanceTraveled((prev) => {
            const newDistance = prev + segmentDistance * 1000
            lastPosition = currentPosition
            return newDistance
          })
        }

        // Calcular distancia restante
        if (selectedRoute?.destinationStop?.coordinates) {
          const destLat = selectedRoute.destinationStop.coordinates.latitude
          const destLon = selectedRoute.destinationStop.coordinates.longitude
          if (isFinite(destLat) && isFinite(destLon)) {
            const remaining = calculateDistance(
              latitude,
              longitude,
              destLat,
              destLon
            )
            setDistanceRemaining(remaining)

            // Verificar si ha llegado al destino (dentro de 100 metros)
            if (remaining < 0.1) {
              handleStopTrip()
              setShowArrivalNotification(true)
            }
          }
        } else if (selectedDestination) {
          const destLat = selectedDestination.lat
          const destLon = selectedDestination.lon
          if (isFinite(destLat) && isFinite(destLon)) {
            const remaining = calculateDistance(
              latitude,
              longitude,
              destLat,
              destLon
            )
            setDistanceRemaining(remaining)

            // Verificar si ha llegado al destino (dentro de 100 metros)
            if (remaining < 0.1) {
              handleStopTrip()
              setShowArrivalNotification(true)
            }
          }
        }

        // Actualizar dirección
        getAddressFromCoordinates(latitude, longitude).then(setCurrentAddress)
      },
      (error) => {
        console.error('Error al rastrear ubicación:', error)
        setError('Error al rastrear tu ubicación. Verifica que el GPS esté activo.')
      },
      {
        enableHighAccuracy: true,
        timeout: 15000, // Aumentado a 15 segundos
        maximumAge: 3000, // Reducido para obtener ubicación más fresca
      }
    )

    setTrackingId(id)
  }

  const handleStopTrip = () => {
    if (trackingId) {
      navigator.geolocation.clearWatch(trackingId)
      setTrackingId(null)
    }
    setIsTracking(false)
    setTripStartTime(null)
    setElapsedTime(0)
    setDistanceRemaining(0)
    setDistanceTraveled(0)
    setTrackingPanelVisible(true)
  }

  // Manejar interacción con el mapa
  const handleMapInteraction = () => {
    if (isTracking) {
      setIsUserInteracting(true)
      setLastUserActivity(Date.now())
    }
  }

  // Manejar el conteo de la alerta de inicio de viaje
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null
    if (showStartTripAlert && countdownSeconds > 0) {
      interval = setInterval(() => {
        setCountdownSeconds((prev) => prev - 1)
      }, 1000)
    } else if (countdownSeconds === 0 && showStartTripAlert) {
      // Auto-cerrar después de 30 segundos
      setShowStartTripAlert(false)
      setIsMenuOpen(true)
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [showStartTripAlert, countdownSeconds])

  // Alternar entre mostrar distancia y tiempo durante el viaje
  useEffect(() => {
    if (isTracking) {
      const interval = setInterval(() => {
        setShowDistance((prev) => !prev)
      }, 3000)
      return () => clearInterval(interval)
    }
  }, [isTracking])

  const handleStartTripFromAlert = () => {
    setShowStartTripAlert(false)
    if (selectedRoute || selectedDestination) {
      handleStartTrip()
      // Enfocar en la ubicación del usuario
      if (currentLocation) {
        setMapCenter([currentLocation.latitude, currentLocation.longitude])
        setMapZoom(16)
      }
    }
  }

  const handleCancelStartTrip = () => {
    setShowStartTripAlert(false)
    // Mostrar botón de detener viaje y abrir el menú principal inmediatamente
    setShowStopTripButton(true)
    setIsMenuOpen(true)
    // Limpiar mapBounds inmediatamente para evitar conflictos con el menú abierto
    setMapBounds(null)
  }

  const handleStopTripAndReset = () => {
    // Detener el viaje y reiniciar la búsqueda de destino
    handleResetSearch()
    setShowStopTripButton(false)
  }

  return (
    <div
      className="relative h-screen w-screen overflow-hidden bg-gray-100"
      onClick={() => isTracking && setTrackingPanelVisible(!trackingPanelVisible)}
    >
      {/* Full Screen Map */}
      {currentLocation && mapCenter && isFinite(mapCenter[0]) && isFinite(mapCenter[1]) && (
        <div className="absolute inset-0 z-0">
          <BusMap
            center={mapCenter}
            zoom={mapZoom}
            bounds={mapBounds}
            userLocation={[currentLocation.latitude, currentLocation.longitude]}
            nearestStop={nearestStop}
            plannedRoutes={plannedRoutes}
            plannedRoutesLength={plannedRoutes.length}
            selectedRoute={selectedRoute}
            destinationCoordinates={selectedDestination ? {
              name: selectedDestination.name || 'Destino',
              latitude: selectedDestination.lat,
              longitude: selectedDestination.lon,
              displayName: selectedDestination.displayName
            } : null}
            routePath={routePath}
            busStops={busStops}
            isTracking={isTracking}
            onMapInteraction={handleMapInteraction}
            tripDistance={distanceTraveled}
            tripTime={elapsedTime}
            showDistanceInfo={isTracking}
          />
        </div>
      )}

      {/* Loading Overlay - Solo muestra cuando no hay ubicación */}
      {!currentLocation && loadingLocation && (
        <div className="absolute inset-0 bg-white/90 flex items-center justify-center z-20">
          <div className="text-center">
            <Loader2 className="w-12 h-12 animate-spin mx-auto mb-3 text-[#E31837]" />
            <p className="text-sm text-[#6B7280]">Obteniendo tu ubicación...</p>
          </div>
        </div>
      )}

      {/* Panel de seguimiento de viaje - Debajo del icono de seguimiento */}
      {isTracking && trackingPanelVisible && (
        <div 
          className={`absolute bottom-20 left-1/2 transform -translate-x-1/2 z-40 transition-all duration-500 ${
            showDistance ? 'opacity-100 blur-0' : 'opacity-60 blur-[2px]'
          }`}
        >
          <Card className="bg-white/95 backdrop-blur-sm shadow-lg border-2 border-[#10B981]">
            <CardContent className="p-2 text-center">
              {showDistance ? (
                <div className="flex items-center justify-center gap-2">
                  <Navigation className="w-4 h-4 text-[#E31837]" />
                  <p className="font-bold text-[#E31837] text-sm">
                    {distanceRemaining.toFixed(1)} km
                  </p>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2">
                  <Clock className="w-4 h-4 text-[#0052B4]" />
                  <p className="font-bold text-[#0052B4] text-sm">
                    {elapsedTime < 60
                      ? `${Math.floor(elapsedTime)} min`
                      : `${Math.floor(elapsedTime / 60)}h ${Math.floor(elapsedTime % 60)}min`}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Alerta de inicio de viaje con conteo de 30 segundos */}
      {showStartTripAlert && selectedDestination && !isTracking && (
        <div className="absolute inset-0 z-50 bg-black/30 flex items-center justify-center p-4">
          <Card className="max-w-[280px] w-full bg-white shadow-xl rounded-lg">
            <CardContent className="p-4 text-center">
              <div className="w-14 h-14 bg-[#10B981] rounded-full flex items-center justify-center mx-auto mb-3">
                <Navigation className="w-7 h-7 text-white" />
              </div>
              <h3 className="font-bold text-[#374151] text-lg mb-2">¿Quieres empezar el viaje?</h3>
              <p className="text-xs text-[#6B7280] mb-1">
                Destino: {selectedDestination.displayName || selectedDestination.name}
              </p>
              <p className="text-2xl font-bold text-[#E31837] mb-4">{countdownSeconds}s</p>
              <div className="flex gap-2 justify-center">
                <Button
                  onClick={handleCancelStartTrip}
                  variant="outline"
                  size="sm"
                  className="flex-1"
                >
                  No
                </Button>
                <Button
                  onClick={handleStartTripFromAlert}
                  size="sm"
                  className="flex-1 bg-[#10B981] hover:bg-[#059669]"
                >
                  Sí
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Notificación de llegada */}
      {showArrivalNotification && (
        <div className="absolute top-20 left-4 right-4 z-50">
          <Card className="bg-[#10B981] border-2 border-[#059669] shadow-xl">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-3">
                <Navigation className="w-8 h-8 text-[#10B981]" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">¡Has llegado a tu destino!</h3>
              <p className="text-white/90 mb-4">
                {selectedRoute?.destinationStop?.name || destination}
              </p>
              <div className="flex gap-2 justify-center">
                <Button
                  onClick={() => setShowArrivalNotification(false)}
                  variant="secondary"
                  size="sm"
                >
                  Cerrar
                </Button>
                <Button
                  onClick={() => {
                    setShowArrivalNotification(false)
                    handleResetSearch()
                  }}
                  size="sm"
                  className="bg-white text-[#10B981] hover:bg-gray-100"
                >
                  Nueva Ruta
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Menu Bar on Left Edge */}
      <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
        <SheetTrigger asChild>
          <div className="absolute top-1/2 left-0 transform -translate-y-1/2 z-30 bg-white/95 backdrop-blur-sm shadow-lg hover:shadow-xl transition-shadow rounded-r-lg cursor-pointer w-3 h-24 flex items-center justify-center">
            <div className="space-y-1">
              <div className="w-1 h-6 bg-gray-400 rounded-full"></div>
              <div className="w-1 h-6 bg-gray-400 rounded-full"></div>
              <div className="w-1 h-6 bg-gray-400 rounded-full"></div>
            </div>
          </div>
        </SheetTrigger>
        <SheetContent side="left" className="w-full sm:w-96 overflow-y-auto">
          <SheetHeader className="sr-only">
            <SheetTitle>Menú Principal de RutaTica</SheetTitle>
            <SheetDescription>Panel lateral con opciones de planificación de rutas y configuración de perfil</SheetDescription>
          </SheetHeader>
          <div className="mt-4 space-y-4">
            {/* Header Content */}
            <div className="flex items-center gap-2 pb-4 border-b">
              <div className="flex items-center justify-center w-10 h-10 bg-red-100 rounded-full">
                <Bus className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h1 className="text-xl font-bold leading-tight">
                  <span className="text-[#0052B4]">Ruta</span>
                  <span className="text-[#E31837]">Tica</span>
                </h1>
                <p className="text-xs text-gray-500">Toda Costa Rica en una APP</p>
              </div>
            </div>

            {/* Profile Section */}
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-center w-10 h-10 bg-[#E31837] rounded-full">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-semibold text-sm text-[#374151]">Mi Perfil</p>
                <p className="text-xs text-[#6B7280]">Configuración y preferencias</p>
              </div>
            </div>
            {/* Current Route Info */}
            {hasPlanned && (
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-[#0052B4]">
                    Ruta a {destination}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleResetSearch}
                    className="text-xs border-[#E5E7EB] text-gray-600 hover:bg-red-50 hover:text-red-600"
                  >
                    <X className="w-3 h-3 mr-1" />
                    Reiniciar
                  </Button>
                </div>
              </div>
            )}
                  {/* Current Location Info */}
                  {!hasPlanned && currentLocation && (
                    <Card className="shadow-sm border border-[#E5E7EB]">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-[#0052B4] rounded-full flex items-center justify-center">
                            <MapPin className="w-3.5 h-3.5 text-white" />
                          </div>
                          <span className="font-semibold text-sm text-[#374151]">Origen (tu ubicación)</span>
                        </div>
                        {loadingLocation || loadingAddress ? (
                          <div className="flex items-center gap-2 text-muted-foreground p-3 bg-blue-50 rounded-lg border border-[#E5E7EB]">
                            <Loader2 className="w-4 h-4 animate-spin text-[#0052B4]" />
                            <span className="text-sm">
                              {loadingLocation ? 'Obteniendo ubicación...' : 'Obteniendo dirección...'}
                            </span>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <div className="bg-white rounded-lg p-3 border border-[#E5E7EB] shadow-sm">
                              <p className="text-sm leading-relaxed text-[#374151]">{currentAddress}</p>
                            </div>

                            <div className="flex items-center justify-between gap-2">
                              <Label htmlFor="address-toggle" className="text-xs cursor-pointer text-[#6B7280]">
                                Dirección {showFullAddress ? 'completa' : 'corta'}
                              </Label>
                              <Switch
                                id="address-toggle"
                                checked={showFullAddress}
                                onCheckedChange={setShowFullAddress}
                                className="scale-90"
                              />
                            </div>

                            {nearestStop && (
                              <div className="flex items-center gap-2 text-xs text-[#6B7280] bg-green-50 p-2 rounded-lg border border-[#E5E7EB]">
                                <Bus className="w-3.5 h-3.5 text-[#10B981]" />
                                <span>
                                  Parada: <span className="font-semibold text-[#10B981]">{nearestStop.name}</span>
                                </span>
                                <Badge variant="secondary" className="ml-auto text-xs bg-green-100 text-[#10B981] border-green-200">
                                  {nearestStop.distance.toFixed(1)} km
                                </Badge>
                              </div>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}

                  {/* Quick Access Buttons */}
                  {!hasPlanned && (
                    <div className="grid grid-cols-2 gap-3">
                      <Card className="shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-[#E5E7EB]">
                        <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                          <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mb-2">
                            <Bus className="w-6 h-6 text-[#E31837]" />
                          </div>
                          <span className="font-semibold text-sm text-[#374151]">Rutas</span>
                        </CardContent>
                      </Card>

                      <Card className="shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-[#E5E7EB]">
                        <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                          <div className="w-12 h-12 bg-yellow-50 rounded-full flex items-center justify-center mb-2">
                            <Clock className="w-6 h-6 text-[#F59E0B]" />
                          </div>
                          <span className="font-semibold text-sm text-[#374151]">Horarios</span>
                        </CardContent>
                      </Card>

                      <Card className="shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-[#E5E7EB]">
                        <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                          <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mb-2">
                            <MapPin className="w-6 h-6 text-[#0052B4]" />
                          </div>
                          <span className="font-semibold text-sm text-[#374151]">Cercanos</span>
                        </CardContent>
                      </Card>

                      <Card className="shadow-sm hover:shadow-md transition-shadow cursor-pointer border border-[#E5E7EB]">
                        <CardContent className="p-4 flex flex-col items-center justify-center text-center">
                          <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center mb-2">
                            <Heart className="w-6 h-6 text-[#10B981]" />
                          </div>
                          <span className="font-semibold text-sm text-[#374151]">Favoritos</span>
                        </CardContent>
                      </Card>
                    </div>
                  )}
            {/* Destination - Labelbox style */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-[#E31837] rounded-full flex items-center justify-center">
                  <Navigation className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="font-semibold text-sm text-[#374151]">Destino</span>
              </div>
              
              {/* Labelbox showing selected destination */}
              {selectedDestination ? (
                <div className="bg-gradient-to-r from-red-50 to-red-100 p-4 rounded-lg border-2 border-[#E31837]">
                  <div className="flex items-center gap-2">
                    <Navigation className="w-5 h-5 text-[#E31837]" />
                    <div className="flex-1">
                      <p className="font-semibold text-sm text-[#374151]">
                        {selectedDestination.displayName || selectedDestination.name}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleResetSearch}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  {/* Botón Empezar/Detener Viaje para destino directo */}
                  {!selectedRoute && (
                    !isTracking ? (
                      <>
                        <Button
                          onClick={handleStartTripFromAlert}
                          className="w-full h-10 text-sm font-semibold bg-[#10B981] hover:bg-[#059669] shadow-md"
                        >
                          <Navigation className="w-4 h-4 mr-2" />
                          Empezar Viaje
                        </Button>
                        {/* Botón Detener Viaje - aparece cuando el usuario canceló el inicio de viaje */}
                        {showStopTripButton && (
                          <Button
                            onClick={handleStopTripAndReset}
                            className="w-full h-10 text-sm font-semibold bg-white text-red-600 border-2 border-red-600 hover:bg-red-50 mt-2"
                          >
                            <X className="w-4 h-4 mr-2" />
                            Detener Viaje
                          </Button>
                        )}
                      </>
                    ) : (
                      <Button
                        onClick={handleStopTrip}
                        className="w-full h-10 text-sm font-semibold bg-white text-red-600 border-2 border-red-600 hover:bg-red-50"
                      >
                        <Navigation className="w-4 h-4 mr-2" />
                        Detener Viaje
                      </Button>
                    )
                  )}
                </div>
              ) : (
                <>
                  {/* Search textbox for autocomplete */}
                  <LocationAutocomplete
                    value={destination}
                    onChange={setDestination}
                    onSelect={handleDestinationSelect}
                    placeholder="Escribe el destino..."
                    disabled={!currentLocation || planning}
                  />
                </>
              )}
            </div>
                  {/* Error Message */}
                  {error && !hasPlanned && (
                    <Card className="border border-[#FECACA] bg-red-50">
                      <CardContent className="p-4 text-center text-[#DC2626]">
                        {error}
                      </CardContent>
                    </Card>
                  )}

                  {/* Planned Routes */}
                  {hasPlanned && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h2 className="text-xl font-bold flex items-center gap-2 text-gray-800">
                          <Bus className="w-5 h-5 text-red-600" />
                          Rutas Encontradas
                          {plannedRoutes.length > 0 && (
                            <Badge className="bg-red-600 text-white border-none">{plannedRoutes.length}</Badge>
                          )}
                        </h2>
                      </div>

                      {plannedRoutes.length === 0 ? (
                        <Card className="p-6 text-center shadow-sm border border-[#E5E7EB]">
                          <Bus className="w-16 h-16 mx-auto text-[#9CA3AF] mb-4" />
                          <p className="text-[#6B7280] text-sm">
                            No se encontraron rutas disponibles hacia "{destination}".
                            Intenta con otro destino más cercano o verifica que el nombre sea correcto.
                          </p>
                        </Card>
                      ) : (
                        <div className="space-y-3">
                          {plannedRoutes.map((route) => (
                            <Card
                              key={route.id}
                              className={`hover:shadow-md transition-all cursor-pointer shadow-sm ${
                                selectedRoute?.id === route.id
                                  ? 'ring-2 ring-[#E31837] shadow-md border border-[#FECACA]'
                                  : 'border border-[#E5E7EB] hover:border-[#FECACA]'
                              }`}
                              onClick={() => {
                                setSelectedRoute(route)
                              }}
                            >
                              <CardContent className="p-4">
                                <div className="space-y-3">
                                  {/* Route Header */}
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center">
                                        <Bus className="w-5 h-5 text-[#E31837]" />
                                      </div>
                                      <div>
                                        <span className="font-bold text-lg text-[#374151]">{route.routeNumber}</span>
                                        <Badge variant="outline" className="ml-2 text-xs border-[#BFDBFE] text-[#0052B4]">
                                          {route.company}
                                        </Badge>
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <div className="flex items-center gap-1 text-[#E31837] font-bold text-lg">
                                        <DollarSign className="w-5 h-5" />
                                        {formatPrice(route.price)}
                                      </div>
                                    </div>
                                  </div>

                                  {/* Distance Indicator - Prominent */}
                                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-4 shadow-md">
                                    <div className="flex items-center justify-between text-white">
                                      <div className="flex items-center gap-2">
                                        <MapPin className="w-6 h-6" />
                                        <span className="text-sm font-medium">Distancia total</span>
                                      </div>
                                      <div className="flex items-baseline gap-1">
                                        <span className="text-3xl font-bold">
                                          {route.distanceKm ? route.distanceKm.toFixed(1) : '--'}
                                        </span>
                                        <span className="text-xl font-semibold">km</span>
                                      </div>
                                    </div>
                                    {formatDuration(route.durationMin) && (
                                      <div className="mt-2 pt-2 border-t border-white/20 flex items-center gap-2 text-white/90">
                                        <Clock className="w-4 h-4" />
                                        <span className="text-sm">Tiempo estimado: {formatDuration(route.durationMin)}</span>
                                      </div>
                                    )}
                                  </div>

                                  {/* Route Path */}
                                  <div className="bg-gradient-to-r from-blue-50 to-red-50 rounded-lg p-3 space-y-2">
                                    {/* Boarding */}
                                    <div className="flex items-start gap-2">
                                      <div className="flex flex-col items-center">
                                        <div className="w-3 h-3 rounded-full bg-[#0052B4]" />
                                        <div className="w-0.5 h-8 bg-blue-200" />
                                      </div>
                                      <div className="flex-1">
                                        <p className="text-xs text-[#6B7280] mb-1">Sube en:</p>
                                        <p className="font-semibold text-sm text-[#374151]">{route.boardingStop.name}</p>
                                        {route.boardingStop.city && (
                                          <p className="text-xs text-[#6B7280]">{route.boardingStop.city}</p>
                                        )}
                                        <p className="text-xs text-[#0052B4] mt-1 font-medium">
                                          {route.nearbyStops[0]?.distance.toFixed(1)} km de tu ubicación
                                        </p>
                                      </div>
                                    </div>

                                    {/* Arrow */}
                                    <div className="flex items-center justify-center">
                                      <ArrowRight className="w-5 h-5 text-[#9CA3AF]" />
                                    </div>

                                    {/* Destination */}
                                    <div className="flex items-start gap-2">
                                      <div>
                                        <div className="w-3 h-3 rounded-full bg-[#E31837]" />
                                      </div>
                                      <div className="flex-1">
                                        <p className="text-xs text-[#6B7280] mb-1">Baja en:</p>
                                        <p className="font-semibold text-sm text-[#374151]">
                                          {route.destinationStop?.name || route.destination}
                                        </p>
                                        {route.destinationStop?.city && (
                                          <p className="text-xs text-[#6B7280]">{route.destinationStop.city}</p>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Botón de Viaje - Empezar/Detener */}
                  {hasPlanned && plannedRoutes.length > 0 && selectedRoute && (
                    <div className="mt-4">
                      {!isTracking ? (
                        <Button
                          onClick={handleStartTrip}
                          className="w-full h-12 text-base font-semibold bg-[#10B981] hover:bg-[#059669] shadow-md"
                        >
                          <Navigation className="w-5 h-5 mr-2" />
                          Empezar Viaje
                        </Button>
                      ) : (
                        <Button
                          onClick={handleStopTrip}
                          className="w-full h-12 text-base font-semibold bg-white text-red-600 border-2 border-red-600 hover:bg-red-50"
                        >
                          <Navigation className="w-5 h-5 mr-2" />
                          Detener Viaje
                        </Button>
                      )}
                    </div>
                  )}

                  {/* Información del viaje activo */}
                  {isTracking && (
                    <Card className="shadow-md border-2 border-[#E31837]">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-3">
                          <div className="w-8 h-8 bg-[#E31837] rounded-full flex items-center justify-center">
                            <Navigation className="w-4 h-4 text-white" />
                          </div>
                          <h3 className="font-bold text-base text-[#374151]">Viaje en curso</h3>
                        </div>
                        {(selectedRoute || selectedDestination) && (
                          <div className="mb-3 text-sm text-[#6B7280] bg-gray-50 p-2 rounded-lg">
                            <span className="font-medium text-[#374151]">Hacia: </span>
                            {selectedRoute?.destinationStop?.name || selectedDestination?.displayName || selectedDestination?.name}
                          </div>
                        )}
                        <div className="grid grid-cols-2 gap-3">
                          <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                            <div className="flex items-center gap-2 mb-1">
                              <MapPin className="w-4 h-4 text-[#0052B4]" />
                              <span className="text-xs text-[#6B7280] font-medium">Distancia</span>
                            </div>
                            <p className="text-lg font-bold text-[#0052B4]">
                              {distanceTraveled >= 1000
                                ? `${(distanceTraveled / 1000).toFixed(2)} km`
                                : `${distanceTraveled.toFixed(2)} m`}
                            </p>
                          </div>
                          <div className="bg-green-50 rounded-lg p-3 border border-green-200">
                            <div className="flex items-center gap-2 mb-1">
                              <Clock className="w-4 h-4 text-[#10B981]" />
                              <span className="text-xs text-[#6B7280] font-medium">Tiempo</span>
                            </div>
                            <p className="text-lg font-bold text-[#10B981]">
                              {elapsedTime < 60
                                ? `${elapsedTime.toFixed(2)} min`
                                : `${(elapsedTime / 60).toFixed(2)} h`}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Popular Destinations */}
                  {!hasPlanned && !error && currentLocation && (
                    <div className="space-y-3">
                      <h3 className="font-bold text-lg text-[#374151]">Destinos Populares</h3>
                      <div className="grid grid-cols-2 gap-3">
                        {['Liberia', 'Puntarenas', 'Limón', 'Alajuela', 'Ciudad Quesada', 'Guápiles'].map((dest) => (
                          <Button
                            key={dest}
                            variant="outline"
                            onClick={() => {
                              setDestination(dest)
                              handlePlanRoute()
                            }}
                            disabled={!currentLocation || planning}
                            className="h-auto py-3 flex flex-col items-center gap-2 border border-[#E5E7EB] hover:border-[#FECACA] hover:bg-red-50 text-[#374151]"
                          >
                            <MapPin className="w-5 h-5 text-[#E31837]" />
                            <span className="font-semibold text-sm">{dest}</span>
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
          </div>
        </SheetContent>
      </Sheet>

      {/* Focus Location Button - Bottom Left - Solo visible cuando hay ubicación */}
      {currentLocation && (
        <Button
          onClick={(e) => {
            e.stopPropagation()
            handleFocusLocation()
          }}
          variant="ghost"
          size="icon"
          className="absolute bottom-20 left-4 z-50 bg-white/95 backdrop-blur-sm shadow-md hover:bg-gray-100 w-12 h-12"
          title="Enfocar en mi ubicación"
        >
          <Navigation className="w-6 h-6 text-[#0052B4]" />
        </Button>
      )}

      {/* Floating Alert Button */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-4 right-4 z-30 bg-white/95 backdrop-blur-sm shadow-md hover:bg-gray-100 w-12 h-12"
      >
        <Bell className="w-6 h-6 text-gray-600" />
      </Button>
    </div>
  )
}
